import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/layout/Sidebar";
import MobileMenu from "@/components/layout/MobileMenu";
import Home from "@/pages/Home";
import Calendar from "@/pages/Calendar";
import Staff from "@/pages/Staff";
import Inventory from "@/pages/Inventory";
import Guest from "@/pages/Guest";
import Links from "@/pages/Links";
import { useState } from "react";

function Router() {
  const [location] = useLocation();
  const getActiveTab = () => {
    if (location === "/") return "home";
    if (location === "/calendar") return "calendar";
    if (location === "/staff") return "staff";
    if (location === "/inventory") return "inventory";
    if (location === "/guest") return "guest";
    if (location === "/links") return "links";
    return "";
  };

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar for desktop */}
      <Sidebar activeTab={getActiveTab()} />
      
      {/* Mobile header */}
      <div className="md:hidden flex items-center justify-between h-16 bg-primary px-4 w-full fixed top-0 z-10">
        <div className="flex items-center">
          <svg className="h-8 w-auto mr-2 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
            <polyline points="9 22 9 12 15 12 15 22"></polyline>
          </svg>
          <h1 className="text-white font-semibold text-lg">Front Desk Hub</h1>
        </div>
        <button 
          type="button" 
          className="text-white" 
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
        activeTab={getActiveTab()} 
      />

      {/* Main content area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none pt-16 md:pt-0">
          <div className="py-6 glass-panel bg-opacity-50 min-h-screen">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/calendar" component={Calendar} />
                <Route path="/staff" component={Staff} />
                <Route path="/inventory" component={Inventory} />
                <Route path="/guest" component={Guest} />
                <Route path="/links" component={Links} />
                <Route component={NotFound} />
              </Switch>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;

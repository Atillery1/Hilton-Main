import { ReactNode } from 'react';
import { Card } from '@/components/ui/card';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  return (
    <div className="flex flex-col lg:flex-row gap-6 max-w-[1600px] mx-auto px-4 py-6">
      {children}
    </div>
  );
};

interface DashboardCardProps {
  title?: string;
  icon?: string;
  className?: string;
  children: ReactNode;
  date?: string;
  action?: ReactNode;
}

export const DashboardCard = ({ 
  title, 
  icon, 
  className = "", 
  children, 
  date,
  action
}: DashboardCardProps) => {
  // Mapping of icon names to SVG elements
  const icons: Record<string, JSX.Element> = {
    calendar: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-400 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
        <line x1="16" y1="2" x2="16" y2="6"></line>
        <line x1="8" y1="2" x2="8" y2="6"></line>
        <line x1="3" y1="10" x2="21" y2="10"></line>
      </svg>
    ),
    award: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-yellow-400 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="8" r="7"></circle>
        <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
      </svg>
    ),
    note: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-green-400 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
    ),
    users: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-300 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
        <circle cx="9" cy="7" r="4"></circle>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
      </svg>
    ),
    crown: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-yellow-500 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"></path>
      </svg>
    ),
    parking: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-500 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
        <path d="M9 17V7h4a3 3 0 0 1 0 6H9"></path>
      </svg>
    ),
    map: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-green-500 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon>
        <line x1="8" y1="2" x2="8" y2="18"></line>
        <line x1="16" y1="6" x2="16" y2="22"></line>
      </svg>
    ),
    link: (
      <svg xmlns="http://www.w3.org/2000/svg" className="text-yellow-400 mr-2 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
      </svg>
    )
  };

  return (
    <Card className={`p-6 shadow-xl backdrop-blur-md bg-zinc-900/70 border border-zinc-800/80 rounded-xl hover:shadow-2xl transition-all duration-300 transform ${className}`}>
      {title && (
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-xl font-semibold text-white flex items-center drop-shadow-sm">
            {icon && icons[icon]}
            {title}
          </h2>
          {date && <span className="text-sm font-medium text-white/90 bg-zinc-800 px-3 py-1 rounded-full">{date}</span>}
          {action}
        </div>
      )}
      <div className="relative z-10">
        {children}
      </div>
      <div className="absolute inset-0 bg-gradient-to-br from-zinc-900/40 to-black/60 rounded-xl -z-10"></div>
    </Card>
  );
};

export default DashboardLayout;

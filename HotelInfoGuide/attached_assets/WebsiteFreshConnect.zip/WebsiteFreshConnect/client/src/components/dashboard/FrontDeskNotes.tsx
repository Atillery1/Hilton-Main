import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { frontDeskNotes } from '@/lib/data';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';

const FrontDeskNotes = () => {
  const [newNote, setNewNote] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    
    // In a real app, this would add a note to the server
    // For now, just clear the input
    setNewNote('');
  };

  return (
    <DashboardCard title="Front Desk Notes" icon="note">
      <div className="max-h-[350px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-green-600 scrollbar-track-zinc-800">
        <div className="space-y-3">
          {frontDeskNotes.map((note) => (
            <div key={note.id} className="bg-gradient-to-r from-green-900/20 to-zinc-900/60 backdrop-blur-sm p-4 rounded-lg shadow-md border-l-4 border-green-500 hover:translate-x-1 transition-all duration-200">
              <p className="text-sm text-white">{note.text}</p>
              <div className="flex items-center mt-2">
                <div className="h-5 w-5 rounded-full bg-green-600 flex items-center justify-center text-xs text-white font-bold">
                  {note.author.substring(0, 1).toUpperCase()}
                </div>
                <p className="text-xs text-green-200 ml-2">- {note.author}, {note.timestamp}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-zinc-800/50">
        <form className="flex items-center" onSubmit={handleSubmit}>
          <Input
            type="text"
            placeholder="Add a note..."
            className="flex-1 bg-zinc-800/70 border-zinc-700 focus:border-green-500 focus:ring-1 focus:ring-green-500 text-white placeholder:text-zinc-400"
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
          />
          <Button
            type="submit"
            variant="ghost" 
            className="ml-2 text-green-400 rounded-full hover:bg-green-900/30 hover:text-green-300 p-2"
          >
            <PlusCircle className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </DashboardCard>
  );
};

export default FrontDeskNotes;

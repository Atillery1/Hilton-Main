import { motivationalQuote } from '@/lib/data';

const MotivationalQuote = () => {
  return (
    <div className="h-full relative overflow-hidden">
      <div className="bg-gradient-to-br from-green-900/30 via-zinc-900/80 to-black rounded-xl p-6 text-center border border-green-800/30 h-full flex flex-col justify-center items-center shadow-lg backdrop-blur-md relative">
        {/* Abstract decorative elements */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-green-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-green-600/10 rounded-full blur-2xl"></div>
        
        <div className="bg-zinc-900/40 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4 relative z-10 shadow-lg">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-7 w-7 text-green-400"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
            <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" />
          </svg>
        </div>
        
        <h3 className="text-lg font-medium text-green-300 mb-4 relative z-10 drop-shadow-md">
          Motivational Quote of the Day
        </h3>
        
        <div className="bg-zinc-900/30 rounded-lg p-4 backdrop-blur-sm max-w-md mx-auto border border-green-800/20 relative z-10 shadow-xl">
          <p className="text-white text-lg italic font-light leading-relaxed">"{motivationalQuote.text}"</p>
          <div className="mt-3 inline-block bg-green-900/40 px-4 py-1 rounded-full">
            <p className="text-sm text-green-200">— {motivationalQuote.author}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MotivationalQuote;

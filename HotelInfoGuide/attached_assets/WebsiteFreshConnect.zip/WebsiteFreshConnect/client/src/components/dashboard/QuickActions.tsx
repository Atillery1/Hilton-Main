import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { Link } from 'wouter';

const QuickActions = () => {
  const actions = [
    { id: 1, icon: 'file-plus', label: 'New Parking Pass', href: '/guest' },
    { id: 2, icon: 'phone', label: 'Contact Staff', href: '/staff' },
    { id: 3, icon: 'calculator', label: 'Room Calculator', href: '/guest' },
    { id: 4, icon: 'map-pin', label: 'Local Info', href: '/guest' },
  ];

  const icons: Record<string, JSX.Element> = {
    'file-plus': (
      <svg xmlns="http://www.w3.org/2000/svg" className="block mx-auto text-xl text-blue-400 mb-1 h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="12" y1="18" x2="12" y2="12"></line>
        <line x1="9" y1="15" x2="15" y2="15"></line>
      </svg>
    ),
    'phone': (
      <svg xmlns="http://www.w3.org/2000/svg" className="block mx-auto text-xl text-green-400 mb-1 h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
      </svg>
    ),
    'calculator': (
      <svg xmlns="http://www.w3.org/2000/svg" className="block mx-auto text-xl text-yellow-400 mb-1 h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
        <line x1="8" y1="6" x2="16" y2="6"></line>
        <line x1="8" y1="10" x2="16" y2="10"></line>
        <line x1="8" y1="14" x2="10" y2="14"></line>
        <line x1="12" y1="14" x2="14" y2="14"></line>
        <line x1="16" y1="14" x2="16" y2="14"></line>
        <line x1="8" y1="18" x2="10" y2="18"></line>
        <line x1="12" y1="18" x2="14" y2="18"></line>
        <line x1="16" y1="18" x2="16" y2="18"></line>
      </svg>
    ),
    'map-pin': (
      <svg xmlns="http://www.w3.org/2000/svg" className="block mx-auto text-xl text-blue-500 mb-1 h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>
    )
  };

  return (
    <DashboardCard title="Quick Actions">
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <Link 
            key={action.id} 
            href={action.href} 
            className="p-4 text-center bg-gradient-to-br from-zinc-800/80 to-zinc-900/90 hover:from-zinc-700/80 hover:to-zinc-800/90 rounded-xl transition-all duration-300 cursor-pointer shadow-md hover:shadow-lg border border-zinc-700/50 hover:border-zinc-600/50 hover:scale-105 transform"
          >
            <div className="flex flex-col items-center">
              <div className="mb-2 p-3 rounded-full bg-zinc-700/50 w-14 h-14 flex items-center justify-center">
                {icons[action.icon]}
              </div>
              <span className="text-sm font-medium text-white">{action.label}</span>
            </div>
          </Link>
        ))}
      </div>
    </DashboardCard>
  );
};

export default QuickActions;

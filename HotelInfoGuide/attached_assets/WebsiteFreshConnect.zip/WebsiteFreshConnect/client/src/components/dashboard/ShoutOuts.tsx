import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { shoutOuts } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { PlusIcon } from 'lucide-react';
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

const ShoutOuts = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newShoutout, setNewShoutout] = useState('');

  const handleSubmit = () => {
    // In a real app, this would send data to the server
    // For now, just close the dialog
    setNewShoutout('');
    setIsDialogOpen(false);
  };

  return (
    <>
      <DashboardCard 
        title="Shout-Outs & Achievements" 
        icon="award" 
        action={
          <Button 
            variant="outline" 
            size="sm" 
            className="text-yellow-400 border-yellow-400 hover:bg-yellow-700/30 hover:text-yellow-300 transition-colors"
            onClick={() => setIsDialogOpen(true)}
          >
            <PlusIcon className="h-4 w-4 mr-1" /> Add New
          </Button>
        }
      >
        <div className="space-y-4">
          {shoutOuts.map((shoutout) => (
            <div key={shoutout.id} className="bg-gradient-to-r from-yellow-900/20 to-zinc-900/50 backdrop-blur-sm rounded-lg p-4 border-l-4 border-yellow-500 shadow-md hover:translate-y-[-2px] transition-all duration-300">
              <p className="text-sm text-white italic">"{shoutout.text}"</p>
              <div className="flex items-center mt-2">
                <div className="h-6 w-6 rounded-full bg-yellow-600 flex items-center justify-center text-xs text-white font-bold">
                  {shoutout.author.substring(0, 1).toUpperCase()}
                </div>
                <p className="text-xs text-yellow-200 ml-2">- {shoutout.author}, {shoutout.date}</p>
              </div>
            </div>
          ))}
        </div>
      </DashboardCard>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Shout-Out</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="shoutout">Shout-out Message</Label>
              <Textarea
                id="shoutout"
                placeholder="Recognize a team member for their outstanding work..."
                value={newShoutout}
                onChange={(e) => setNewShoutout(e.target.value)}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="border-yellow-400 text-yellow-400 hover:bg-yellow-400/10">
              Cancel
            </Button>
            <Button onClick={handleSubmit} className="bg-yellow-500 hover:bg-yellow-600 text-black">
              Submit Shout-Out
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ShoutOuts;

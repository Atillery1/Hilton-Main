import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { todaysEvents, vipsForToday, parkingReminders, getCurrentDate } from '@/lib/data';

const TodaysEvents = () => {
  return (
    <DashboardCard 
      title="Today's Events & Notes" 
      icon="calendar" 
      date={getCurrentDate()}
    >
      <div className="space-y-5">
        <div className="rounded-xl bg-gradient-to-r from-yellow-900/30 to-zinc-900/80 p-5 border border-yellow-800/30 backdrop-blur-sm shadow-lg">
          <h3 className="font-medium text-yellow-300 mb-3 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"></path>
            </svg>
            VIPs & Groups Arriving Today
          </h3>
          <ul className="space-y-3">
            {vipsForToday.map((vip) => (
              <li key={vip.id} className="flex items-start bg-zinc-900/60 rounded-lg p-3 border-l-4 border-yellow-500 hover:bg-zinc-800/60 transition-colors">
                <span className={`inline-flex items-center justify-center h-8 w-8 rounded-full ${vip.type.includes('Diamond') ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-gradient-to-r from-blue-400 to-blue-600'} text-black text-xs mr-3 font-bold shadow-md`}>
                  {vip.type.includes('Diamond') ? 'CEO' : 'VIP'}
                </span>
                <div>
                  <p className="text-sm font-medium text-white">{vip.name} - {vip.room}</p>
                  <p className="text-xs text-yellow-200">Arrives {vip.arrivalTime}</p>
                  {vip.specialRequests.length > 0 && (
                    <div className="mt-1">
                      <span className="text-xs text-white/70">Special requests: </span>
                      <span className="text-xs text-yellow-100">{vip.specialRequests.join(', ')}</span>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="rounded-xl bg-gradient-to-r from-blue-900/30 to-zinc-900/80 p-5 border border-blue-800/30 backdrop-blur-sm shadow-lg">
          <h3 className="font-medium text-blue-300 mb-3 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 13v10h-6v-6H9v6H3V13H1l11-11 11 11h-2z"></path>
            </svg>
            Scheduled Meeting Room Events
          </h3>
          <ul className="space-y-3">
            {todaysEvents.map((event) => (
              <li key={event.id} className="flex items-center bg-zinc-900/60 rounded-lg p-3 hover:bg-zinc-800/60 transition-colors">
                <span className="inline-flex items-center justify-center text-xs rounded-lg bg-gradient-to-r from-blue-500 to-blue-700 text-white px-3 py-1.5 mr-3 font-semibold shadow-sm">
                  {event.timeRange}
                </span>
                <div>
                  <p className="text-sm font-medium text-white">{event.title}</p>
                  <p className="text-xs text-blue-200">{event.location} · {event.attendees} attendees</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="rounded-xl bg-gradient-to-r from-green-900/30 to-zinc-900/80 p-5 border border-green-800/30 backdrop-blur-sm shadow-lg">
          <h3 className="font-medium text-green-300 mb-3 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <path d="M9 17V7h4a3 3 0 0 1 0 6H9"></path>
            </svg>
            Parking Pass Reminders
          </h3>
          <ul className="space-y-2">
            {parkingReminders.map((reminder, index) => (
              <li key={index} className="flex items-start">
                <span className="inline-flex h-5 w-5 rounded-full bg-green-500/20 text-green-400 items-center justify-center mr-2 mt-0.5">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </span>
                <p className="text-sm text-white">{reminder}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </DashboardCard>
  );
};

export default TodaysEvents;

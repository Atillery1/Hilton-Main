import { Card } from '@/components/ui/card';
import { currentWeather, weatherForecast } from '@/lib/data';

const WeatherWidget = () => {
  const getWeatherIcon = (icon: string) => {
    const icons: Record<string, JSX.Element> = {
      sun: (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-yellow-400 text-4xl" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="5"></circle>
          <line x1="12" y1="1" x2="12" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="23"></line>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
          <line x1="1" y1="12" x2="3" y2="12"></line>
          <line x1="21" y1="12" x2="23" y2="12"></line>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>
      ),
      'cloud-sun': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-400 text-4xl" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2v2"></path>
          <path d="M5.22 5.22l1.42 1.42"></path>
          <path d="M2 12h2"></path>
          <path d="M12 19a7 7 0 1 0 0-14 7 7 0 0 0 0 14z"></path>
          <path d="M19 19H5a2 2 0 1 1 .4-3.9 4.5 4.5 0 0 1 .8-6.7 4.5 4.5 0 0 1 6.4 0 4.5 4.5 0 0 1 .8 6.7A2 2 0 1 1 19 19z"></path>
        </svg>
      ),
      cloud: (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-gray-400 text-4xl" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
        </svg>
      ),
      'cloud-rain': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-500 text-4xl" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="16" y1="13" x2="16" y2="21"></line>
          <line x1="8" y1="13" x2="8" y2="21"></line>
          <line x1="12" y1="15" x2="12" y2="23"></line>
          <path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"></path>
        </svg>
      )
    };
    
    return icons[icon] || icons.sun;
  };

  const getForecastIcon = (icon: string) => {
    const icons: Record<string, JSX.Element> = {
      sun: (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-yellow-400 my-1 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="5"></circle>
          <line x1="12" y1="1" x2="12" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="23"></line>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
          <line x1="1" y1="12" x2="3" y2="12"></line>
          <line x1="21" y1="12" x2="23" y2="12"></line>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>
      ),
      'cloud-sun': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-400 my-1 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2v2"></path>
          <path d="M5.22 5.22l1.42 1.42"></path>
          <path d="M2 12h2"></path>
          <path d="M12 19a7 7 0 1 0 0-14 7 7 0 0 0 0 14z"></path>
          <path d="M19 19H5a2 2 0 1 1 .4-3.9 4.5 4.5 0 0 1 .8-6.7 4.5 4.5 0 0 1 6.4 0 4.5 4.5 0 0 1 .8 6.7A2 2 0 1 1 19 19z"></path>
        </svg>
      ),
      cloud: (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-gray-400 my-1 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
        </svg>
      ),
      'cloud-rain': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-blue-500 my-1 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="16" y1="13" x2="16" y2="21"></line>
          <line x1="8" y1="13" x2="8" y2="21"></line>
          <line x1="12" y1="15" x2="12" y2="23"></line>
          <path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"></path>
        </svg>
      )
    };
    
    return icons[icon] || icons.sun;
  };

  return (
    <div className="relative h-full">
      <Card className="shadow-lg overflow-hidden bg-gradient-to-br from-blue-900/40 via-zinc-900/70 to-black border border-blue-900/30 h-full">
        <div className="px-6 py-5 text-white relative">
          <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 rounded-full bg-blue-500/20 blur-2xl"></div>
          <div className="flex items-center justify-between relative z-10">
            <h3 className="font-medium text-xl text-blue-200">{currentWeather.location}</h3>
            <span className="text-xs bg-blue-900/50 px-2 py-1 rounded-full text-blue-200">Updated {currentWeather.lastUpdated}</span>
          </div>
          <div className="flex items-center mt-4 relative z-10">
            <div className="bg-blue-900/30 p-3 rounded-full ring-2 ring-blue-500/30 flex items-center justify-center">
              {getWeatherIcon(currentWeather.icon)}
            </div>
            <div className="ml-4">
              <span className="text-4xl font-light text-white drop-shadow">{currentWeather.temperature}</span>
              <p className="text-sm text-blue-100">{currentWeather.condition}, feels like {currentWeather.feelsLike}</p>
            </div>
          </div>
        </div>
        <div className="p-5 bg-zinc-900/80 backdrop-blur-sm relative">
          <h4 className="text-sm font-medium text-blue-300 mb-3">7-Day Forecast</h4>
          <div className="grid grid-cols-7 gap-1 text-xs text-center text-white">
            {weatherForecast.map((day, index) => (
              <div key={index} className="flex flex-col items-center p-2 rounded-lg hover:bg-blue-900/30 transition-colors duration-200">
                <span className="font-medium text-blue-200">{day.day}</span>
                <div className="my-1 p-1 rounded-full bg-zinc-800/50">
                  {getForecastIcon(day.icon)}
                </div>
                <span className="text-blue-100">{day.temp}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default WeatherWidget;

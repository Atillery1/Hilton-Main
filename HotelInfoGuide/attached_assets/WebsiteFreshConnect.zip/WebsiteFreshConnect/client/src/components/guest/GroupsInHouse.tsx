import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { groupsInHouse } from '@/lib/data';

const GroupsInHouse = () => {
  return (
    <DashboardCard title="Groups In House" icon="users">
      <div className="space-y-4">
        {groupsInHouse.map((group) => (
          <div 
            key={group.id} 
            className={`border ${group.name.includes('Wedding') ? 'border-primary border-opacity-30' : 'border-gray-200'} p-4 rounded-md`}
          >
            <div className="flex justify-between">
              <div>
                <h3 className="font-medium text-lg">{group.name}</h3>
                <p className="text-sm text-gray-600">{group.roomCount} Rooms · Block Code: {group.blockCode}</p>
              </div>
              <div className="text-right">
                <span className="block text-sm text-gray-500">{group.dateRange}</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-blue-100 text-blue-800 mt-1">
                  {group.location}
                </span>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t">
              <p className="text-sm">
                <span className="font-medium">Contact:</span> {group.contactName} ({group.contactPhone})
              </p>
              <p className="text-sm mt-1">
                <span className="font-medium">Notes:</span> {group.notes}
              </p>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};

export default GroupsInHouse;

import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { localRecommendations } from '@/lib/data';
import { Button } from '@/components/ui/button';

const LocalRecommendations = () => {
  return (
    <DashboardCard title="Local Recommendations" icon="map">
      <div className="space-y-3">
        {localRecommendations.map((section) => {
          let borderColor = 'border-gray-300';
          
          if (section.category === 'Dining Options') {
            borderColor = 'border-primary';
          } else if (section.category === 'Attractions') {
            borderColor = 'border-amber-400';
          }
          
          return (
            <div key={section.id} className={`border-l-4 ${borderColor} pl-3 py-1`}>
              <h3 className="font-medium">{section.category}</h3>
              <p className="text-sm text-gray-600">Top recommendations within walking distance</p>
              <div className="flex flex-wrap gap-2 mt-2">
                {section.items.map((item, index) => (
                  <span key={index} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                    {item.name} {item.distance && `(${item.distance})`}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 pt-4 border-t">
        <Button 
          variant="outline" 
          className="w-full flex justify-center items-center px-4 bg-primary bg-opacity-10 text-primary rounded-md hover:bg-opacity-20 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="6 9 6 2 18 2 18 9"></polyline>
            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
            <rect x="6" y="14" width="12" height="8"></rect>
          </svg>
          Print Guest Map
        </Button>
      </div>
    </DashboardCard>
  );
};

export default LocalRecommendations;

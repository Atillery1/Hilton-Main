import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { parkingPasses } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { DatePickerWithRange } from '@/components/ui/date-range-picker';
import { Checkbox } from '@/components/ui/checkbox';
import { addDays } from 'date-fns';
import { DateRange } from 'react-day-picker';

const ParkingPassReminders = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [date, setDate] = useState<DateRange | undefined>({
    from: new Date(),
    to: addDays(new Date(), 3),
  });

  return (
    <>
      <DashboardCard title="Parking Pass Reminders" icon="parking">
        <div className="space-y-3">
          {parkingPasses.map((pass) => (
            <div 
              key={pass.id} 
              className={`${pass.isVIP ? 'bg-amber-50' : 'bg-gray-50'} p-3 rounded-md flex items-center justify-between`}
            >
              <div>
                <p className="font-medium">{pass.name}</p>
                <p className="text-sm text-gray-600">{pass.details}</p>
              </div>
              <Button 
                variant="outline" 
                className={`px-3 py-1 rounded-md ${pass.isVIP ? 'text-amber-700 border-amber-200 bg-white' : 'text-gray-700 border-gray-200 bg-white'} text-sm`}
              >
                Print Pass
              </Button>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t">
          <Button 
            variant="outline" 
            className="w-full border-primary text-primary hover:bg-primary hover:bg-opacity-10"
            onClick={() => setIsDialogOpen(true)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            Create New Parking Pass
          </Button>
        </div>
      </DashboardCard>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create New Parking Pass</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Guest/Group Name</Label>
              <Input id="name" placeholder="Enter guest or group name" />
            </div>
            <div className="grid gap-2">
              <Label>Pass Valid Dates</Label>
              <DatePickerWithRange date={date} setDate={setDate} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="spaces">Number of Spaces</Label>
              <Input id="spaces" type="number" defaultValue={1} min={1} />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="vip" />
              <Label htmlFor="vip">Mark as VIP</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsDialogOpen(false)}>Create Pass</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ParkingPassReminders;

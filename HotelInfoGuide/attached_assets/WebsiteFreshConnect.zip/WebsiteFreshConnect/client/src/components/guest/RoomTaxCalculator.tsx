import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const RoomTaxCalculator = () => {
  const [roomRate, setRoomRate] = useState(189);
  const [numNights, setNumNights] = useState(3);
  const [taxRate, setTaxRate] = useState(12.5);
  const [additionalFees, setAdditionalFees] = useState(25);
  const [calculationResults, setCalculationResults] = useState({
    roomSubtotal: 567,
    taxAmount: 70.88,
    totalAmount: 662.88
  });

  const calculateTotal = () => {
    const roomSubtotal = roomRate * numNights;
    const taxAmount = roomSubtotal * (taxRate / 100);
    const totalAmount = roomSubtotal + taxAmount + additionalFees;

    setCalculationResults({
      roomSubtotal,
      taxAmount,
      totalAmount
    });
  };

  return (
    <DashboardCard 
      title="Room & Tax Calculator" 
      icon="calculator"
      className="md:col-span-2"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <form className="space-y-4">
            <div>
              <Label htmlFor="room-rate">Room Rate ($)</Label>
              <Input 
                type="number" 
                id="room-rate" 
                value={roomRate}
                onChange={(e) => setRoomRate(Number(e.target.value))}
              />
            </div>
            
            <div>
              <Label htmlFor="num-nights">Number of Nights</Label>
              <Input 
                type="number" 
                id="num-nights" 
                value={numNights}
                onChange={(e) => setNumNights(Number(e.target.value))}
              />
            </div>
            
            <div>
              <Label htmlFor="tax-rate">Tax Rate (%)</Label>
              <Input 
                type="number" 
                id="tax-rate" 
                value={taxRate}
                onChange={(e) => setTaxRate(Number(e.target.value))}
              />
            </div>
            
            <div>
              <Label htmlFor="additional-fees">Additional Fees ($)</Label>
              <Input 
                type="number" 
                id="additional-fees" 
                value={additionalFees}
                onChange={(e) => setAdditionalFees(Number(e.target.value))}
              />
            </div>
            
            <Button 
              type="button" 
              id="calculate-btn"
              onClick={calculateTotal}
            >
              Calculate Total
            </Button>
          </form>
        </div>
        
        <div className="bg-gray-50 p-6 rounded-md">
          <h3 className="text-lg font-medium text-gray-800 mb-4">Calculation Results</h3>
          <div id="calculator-results" className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Room Rate per Night:</span>
              <span className="font-medium">${roomRate.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Number of Nights:</span>
              <span className="font-medium">{numNights}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Room Subtotal:</span>
              <span className="font-medium">${calculationResults.roomSubtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Tax ({taxRate}%):</span>
              <span className="font-medium">${calculationResults.taxAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Additional Fees:</span>
              <span className="font-medium">${additionalFees.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center pt-3 border-t">
              <span className="text-base font-semibold">Total Amount:</span>
              <span className="text-lg font-bold text-primary">${calculationResults.totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};

export default RoomTaxCalculator;

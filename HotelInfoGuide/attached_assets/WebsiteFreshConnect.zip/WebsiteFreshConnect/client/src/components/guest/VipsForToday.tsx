import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { vipsForToday } from '@/lib/data';

const VipsForToday = () => {
  return (
    <DashboardCard title="VIPs for Today" icon="crown">
      <div className="space-y-4">
        {vipsForToday.map((vip) => (
          <div 
            key={vip.id} 
            className={`${vip.type.includes('Diamond') ? 'bg-amber-50' : 'bg-gray-50'} p-4 rounded-md`}
          >
            <div className="flex justify-between">
              <div>
                <span 
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-sm font-medium ${
                    vip.type.includes('Diamond') 
                      ? 'bg-amber-400 text-white' 
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {vip.type}
                </span>
                <h3 className="font-medium text-lg mt-1">{vip.name}</h3>
                <p className="text-sm text-gray-600">{vip.room}</p>
              </div>
              <div className="text-center">
                <span className="block text-sm font-bold text-gray-700">ARRIVAL</span>
                <span className="block text-lg">{vip.arrivalTime}</span>
              </div>
            </div>
            <div className={`mt-3 pt-3 border-t ${vip.type.includes('Diamond') ? 'border-amber-200' : 'border-gray-200'}`}>
              <h4 className="text-sm font-medium text-gray-700">Special Requests:</h4>
              <ul className="mt-1 text-sm list-disc list-inside">
                {vip.specialRequests.map((request, index) => (
                  <li key={index}>{request}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};

export default VipsForToday;

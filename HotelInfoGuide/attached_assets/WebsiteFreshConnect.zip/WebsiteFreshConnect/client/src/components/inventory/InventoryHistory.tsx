import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { inventoryHistory } from '@/lib/data';

const InventoryHistory = () => {
  const getActionIcon = (type: string) => {
    switch (type) {
      case 'increase':
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="18 15 12 9 6 15"></polyline>
            </svg>
          </div>
        );
      case 'decrease':
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        );
      case 'add':
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  const getActionText = (action: typeof inventoryHistory[0]) => {
    switch (action.type) {
      case 'increase':
        return (
          <p className="text-sm">
            <span className="font-medium">{action.user}</span> updated <span className="font-medium">{action.item}</span> from {action.from} to {action.to}
          </p>
        );
      case 'decrease':
        return (
          <p className="text-sm">
            <span className="font-medium">{action.user}</span> updated <span className="font-medium">{action.item}</span> from {action.from} to {action.to}
          </p>
        );
      case 'add':
        return (
          <p className="text-sm">
            <span className="font-medium">{action.user}</span> added new item <span className="font-medium">{action.item}</span> with quantity {action.to}
          </p>
        );
      default:
        return null;
    }
  };

  return (
    <DashboardCard title="Recent Inventory Activity">
      <div className="space-y-3">
        {inventoryHistory.map((action) => (
          <div key={action.id} className="flex items-start">
            {getActionIcon(action.type)}
            <div className="ml-3">
              {getActionText(action)}
              <p className="text-xs text-gray-500">{action.timestamp}</p>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};

export default InventoryHistory;

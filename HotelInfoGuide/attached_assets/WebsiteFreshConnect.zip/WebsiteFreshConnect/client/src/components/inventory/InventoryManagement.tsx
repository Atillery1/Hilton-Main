import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { inventoryItems } from '@/lib/data';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlusIcon, DownloadIcon } from 'lucide-react';
import { useState } from 'react';

const InventoryManagement = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredItems = inventoryItems.filter(
    item => item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Stock':
        return 'bg-green-100 text-green-800';
      case 'Order Soon':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low Stock':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <DashboardCard 
      title="Inventory Management" 
      icon="package"
      className="mb-6"
    >
      {/* Inventory Tabs */}
      <Tabs defaultValue="desk-supplies" className="w-full">
        <TabsList className="border-b border-gray-200 w-full rounded-none bg-transparent pb-0 mb-4 flex flex-wrap">
          <TabsTrigger 
            value="desk-supplies" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Desk Supplies
          </TabsTrigger>
          <TabsTrigger 
            value="emperyan-lounge" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Emperyan Lounge
          </TabsTrigger>
          <TabsTrigger 
            value="pantry" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Pantry
          </TabsTrigger>
          <TabsTrigger 
            value="amenities" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Amenities
          </TabsTrigger>
        </TabsList>
        
        {/* Inventory Actions */}
        <div className="flex flex-wrap justify-between items-center mb-4">
          <div className="flex space-x-2 mb-2 sm:mb-0">
            <Button 
              size="sm" 
              className="bg-primary text-white"
            >
              <PlusIcon className="h-4 w-4 mr-1" /> Add Item
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-gray-600"
            >
              <DownloadIcon className="h-4 w-4 mr-1" /> Export
            </Button>
          </div>
          
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search inventory..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
            </div>
          </div>
        </div>
        
        <TabsContent value="desk-supplies" className="mt-0">
          {/* Inventory Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Min. Required</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Updated</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredItems.map((item) => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{item.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Input 
                        type="number" 
                        value={item.currentAmount} 
                        className="w-20 text-center"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.minRequired}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.lastUpdated} · {item.lastUpdatedBy}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <Button variant="ghost" className="text-primary hover:text-primary/90 hover:bg-primary/10">
                        Update
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
        
        <TabsContent value="emperyan-lounge" className="mt-0">
          <p className="text-center py-8 text-gray-500">Emperyan Lounge inventory would be displayed here</p>
        </TabsContent>
        
        <TabsContent value="pantry" className="mt-0">
          <p className="text-center py-8 text-gray-500">Pantry inventory would be displayed here</p>
        </TabsContent>
        
        <TabsContent value="amenities" className="mt-0">
          <p className="text-center py-8 text-gray-500">Amenities inventory would be displayed here</p>
        </TabsContent>
      </Tabs>
    </DashboardCard>
  );
};

export default InventoryManagement;

import { Link } from "wouter";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
}

const MobileMenu = ({ isOpen, onClose, activeTab }: MobileMenuProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black z-50 md:hidden">
      <div className="flex flex-col px-4 py-2 bg-black text-white border-b border-zinc-800">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <img src="https://raw.githubusercontent.com/user-attachments/assets/main/logo.png" alt="Front Desk Hub" className="h-12 w-auto" />
          </div>
          <button type="button" onClick={onClose}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
      <nav className="px-2 pt-2 pb-4 bg-black">
        <MobileLink 
          href="/" 
          label="Home" 
          isActive={activeTab === 'home'} 
          onClick={onClose} 
        />
        <MobileLink 
          href="/calendar" 
          label="Calendar & Events" 
          isActive={activeTab === 'calendar'} 
          onClick={onClose} 
        />
        <MobileLink 
          href="/staff" 
          label="Staff Tools" 
          isActive={activeTab === 'staff'} 
          onClick={onClose} 
        />
        <MobileLink 
          href="/inventory" 
          label="Inventory Logs" 
          isActive={activeTab === 'inventory'} 
          onClick={onClose} 
        />
        <MobileLink 
          href="/guest" 
          label="Guest Services" 
          isActive={activeTab === 'guest'} 
          onClick={onClose} 
        />
        <MobileLink 
          href="/links" 
          label="Quick Links" 
          isActive={activeTab === 'links'} 
          onClick={onClose} 
        />
      </nav>
    </div>
  );
};

interface MobileLinkProps {
  href: string;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const MobileLink = ({ href, label, isActive, onClick }: MobileLinkProps) => {
  const baseClasses = "block px-3 py-2 rounded-md text-base font-medium";
  const activeClasses = "text-white bg-zinc-800 border-l-4 border-white";
  const inactiveClasses = "text-white hover:text-white hover:bg-zinc-900";

  return (
    <Link 
      href={href}
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
      onClick={onClick}
    >
      {label}
    </Link>
  );
};

export default MobileMenu;

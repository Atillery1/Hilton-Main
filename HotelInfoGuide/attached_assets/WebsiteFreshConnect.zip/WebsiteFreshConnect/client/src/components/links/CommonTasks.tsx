import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { commonTasks } from '@/lib/data';

const CommonTasks = () => {
  // Map of icon names to SVG elements
  const getIcon = (iconName: string) => {
    const icons: Record<string, JSX.Element> = {
      'file-text': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10 9 9 9 8 9"></polyline>
        </svg>
      ),
      'mail': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
          <polyline points="22,6 12,13 2,6"></polyline>
        </svg>
      ),
      'calendar': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="16" y1="2" x2="16" y2="6"></line>
          <line x1="8" y1="2" x2="8" y2="6"></line>
          <line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
      ),
      'search': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
      )
    };

    return icons[iconName] || icons['file-text'];
  };

  return (
    <DashboardCard title="Common Tasks">
      <div className="space-y-2">
        {commonTasks.map((task) => (
          <a 
            key={task.id} 
            href={task.url} 
            className="block p-3 rounded-md hover:bg-primary hover:bg-opacity-10 transition-all"
          >
            <div className="flex items-center">
              {getIcon(task.icon)}
              <div>
                <p className="font-medium">{task.title}</p>
                <p className="text-xs text-gray-500">{task.description}</p>
              </div>
            </div>
          </a>
        ))}
      </div>
    </DashboardCard>
  );
};

export default CommonTasks;

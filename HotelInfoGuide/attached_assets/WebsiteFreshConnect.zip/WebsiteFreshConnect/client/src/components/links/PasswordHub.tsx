import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

const PasswordHub = () => {
  const [password, setPassword] = useState('');
  const [showError, setShowError] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would validate against an actual password
    // For now, we'll just check if it's not empty
    if (password.trim()) {
      setAuthenticated(true);
      setShowError(false);
    } else {
      setShowError(true);
    }
  };

  return (
    <DashboardCard title="Password Hub">
      {authenticated ? (
        <div className="space-y-3">
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div>
              <h4 className="font-medium">Front Desk System</h4>
              <p className="text-xs text-gray-500">Username: frontdesk</p>
            </div>
            <Button variant="outline" size="sm" className="text-primary">View</Button>
          </div>
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div>
              <h4 className="font-medium">Reservation System</h4>
              <p className="text-xs text-gray-500">Username: hilton_norfolk</p>
            </div>
            <Button variant="outline" size="sm" className="text-primary">View</Button>
          </div>
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div>
              <h4 className="font-medium">Wi-Fi Admin</h4>
              <p className="text-xs text-gray-500">Username: admin</p>
            </div>
            <Button variant="outline" size="sm" className="text-primary">View</Button>
          </div>
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div>
              <h4 className="font-medium">Safe Combination</h4>
              <p className="text-xs text-gray-500">Front Office Safe</p>
            </div>
            <Button variant="outline" size="sm" className="text-primary">View</Button>
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 p-4 rounded-md text-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-12 w-12 text-gray-400 mx-auto mb-2"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
          </svg>
          <p className="text-gray-600 mb-2">Access secure passwords and credentials</p>
          
          {showError && (
            <Alert variant="destructive" className="mb-3">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>Please enter the hub password</AlertDescription>
            </Alert>
          )}
          
          <form className="mt-3" onSubmit={handleSubmit}>
            <div className="mb-3">
              <Input 
                type="password" 
                placeholder="Enter hub password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full"
            >
              Access Secured Content
            </Button>
          </form>
        </div>
      )}
    </DashboardCard>
  );
};

export default PasswordHub;

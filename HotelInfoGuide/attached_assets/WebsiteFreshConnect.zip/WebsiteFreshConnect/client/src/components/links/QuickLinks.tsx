import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { quickLinks } from '@/lib/data';

const QuickLinks = () => {
  // Map of icon names to SVG elements
  const getIcon = (iconName: string) => {
    const icons: Record<string, JSX.Element> = {
      'message-square': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
      ),
      'archive': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="21 8 21 21 3 21 3 8"></polyline>
          <rect x="1" y="3" width="22" height="5"></rect>
          <line x1="10" y1="12" x2="14" y2="12"></line>
        </svg>
      ),
      'home': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          <polyline points="9 22 9 12 15 12 15 22"></polyline>
        </svg>
      ),
      'car': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"></path>
          <circle cx="6.5" cy="16.5" r="2.5"></circle>
          <circle cx="16.5" cy="16.5" r="2.5"></circle>
        </svg>
      ),
      'users': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
          <circle cx="9" cy="7" r="4"></circle>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
        </svg>
      ),
      'tool': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
        </svg>
      ),
      'music': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 18V5l12-2v13"></path>
          <circle cx="6" cy="18" r="3"></circle>
          <circle cx="18" cy="16" r="3"></circle>
        </svg>
      ),
      'globe': (
        <svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary mb-2 h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="2" y1="12" x2="22" y2="12"></line>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
        </svg>
      )
    };

    return icons[iconName] || icons['globe'];
  };

  return (
    <DashboardCard 
      title="Quick Links" 
      icon="link"
      className="mb-6"
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {quickLinks.map((link) => (
          <a 
            key={link.id} 
            href={link.url} 
            className="flex flex-col items-center p-4 rounded-md border border-gray-200 hover:bg-primary hover:bg-opacity-10 hover:border-primary transition-all"
          >
            {getIcon(link.icon)}
            <span className="text-sm font-medium text-gray-700">{link.name}</span>
            <span className="text-xs text-gray-500">{link.description}</span>
          </a>
        ))}
      </div>
    </DashboardCard>
  );
};

export default QuickLinks;

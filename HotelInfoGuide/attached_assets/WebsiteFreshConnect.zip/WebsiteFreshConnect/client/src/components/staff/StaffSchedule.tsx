import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { staffMembers } from '@/lib/data';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const StaffSchedule = () => {
  const getStatusColor = (status: string | undefined) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Coming Soon':
        return 'bg-yellow-100 text-yellow-800';
      case 'Off Duty':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <DashboardCard 
      title="Staff Schedule" 
      icon="users"
      className="mb-6"
    >
      {/* Schedule Tabs */}
      <Tabs defaultValue="today" className="w-full">
        <TabsList className="border-b border-gray-200 w-full rounded-none bg-transparent pb-0 mb-4">
          <TabsTrigger 
            value="today" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Today's Shifts
          </TabsTrigger>
          <TabsTrigger 
            value="week" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            This Week
          </TabsTrigger>
          <TabsTrigger 
            value="request" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Request Time Off
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="today" className="mt-0">
          {/* Today's Shifts Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Staff Member</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Position</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Shift Time</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {staffMembers.map((staff) => (
                  <tr key={staff.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-8 w-8">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary bg-opacity-20 text-primary">
                              {staff.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{staff.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{staff.position}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{staff.shiftTime}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(staff.status)}`}>
                        {staff.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
        
        <TabsContent value="week" className="mt-0">
          <div className="border rounded-md p-6 text-center bg-gray-50">
            <p className="text-gray-500">Weekly schedule would be displayed here</p>
          </div>
        </TabsContent>
        
        <TabsContent value="request" className="mt-0">
          <div className="border rounded-md p-6 text-center bg-gray-50">
            <p className="text-gray-500">Time off request form would be displayed here</p>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardCard>
  );
};

export default StaffSchedule;

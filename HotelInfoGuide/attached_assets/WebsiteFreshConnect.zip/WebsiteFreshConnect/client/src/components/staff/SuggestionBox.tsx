import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';

const SuggestionBox = () => {
  const [suggestionTitle, setSuggestionTitle] = useState('');
  const [suggestionCategory, setSuggestionCategory] = useState('');
  const [suggestionDetails, setSuggestionDetails] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit the suggestion to the server
    console.log({
      title: suggestionTitle,
      category: suggestionCategory,
      details: suggestionDetails,
      isAnonymous
    });
    
    // Reset form
    setSuggestionTitle('');
    setSuggestionCategory('');
    setSuggestionDetails('');
    setIsAnonymous(false);
  };

  return (
    <DashboardCard title="Team Suggestion Box" icon="users">
      <p className="text-sm text-gray-600 mb-4">
        Have an idea to improve our operations or guest experience? Let us know!
      </p>
      
      <form className="space-y-4" onSubmit={handleSubmit}>
        <div>
          <Label htmlFor="suggestion-title">Suggestion Title</Label>
          <Input 
            id="suggestion-title" 
            placeholder="Brief title for your suggestion" 
            value={suggestionTitle}
            onChange={(e) => setSuggestionTitle(e.target.value)}
          />
        </div>
        
        <div>
          <Label htmlFor="suggestion-category">Category</Label>
          <Select value={suggestionCategory} onValueChange={setSuggestionCategory}>
            <SelectTrigger id="suggestion-category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="guest-experience">Guest Experience</SelectItem>
              <SelectItem value="operations">Operations</SelectItem>
              <SelectItem value="staff-wellbeing">Staff Well-being</SelectItem>
              <SelectItem value="efficiency">Efficiency Improvement</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="suggestion-details">Details</Label>
          <Textarea 
            id="suggestion-details" 
            rows={4} 
            placeholder="Describe your suggestion in detail..."
            value={suggestionDetails}
            onChange={(e) => setSuggestionDetails(e.target.value)}
          />
        </div>
        
        <div className="flex items-start">
          <div className="flex items-center h-5">
            <Checkbox 
              id="anonymous" 
              checked={isAnonymous}
              onCheckedChange={(checked) => setIsAnonymous(checked === true)}
            />
          </div>
          <div className="ml-3 text-sm">
            <Label 
              htmlFor="anonymous" 
              className="font-medium text-gray-700 cursor-pointer"
            >
              Submit anonymously
            </Label>
          </div>
        </div>
        
        <Button type="submit">Submit Suggestion</Button>
      </form>
    </DashboardCard>
  );
};

export default SuggestionBox;

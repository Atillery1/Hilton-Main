import { DashboardCard } from '@/components/dashboard/DashboardLayout';
import { staffMembers } from '@/lib/data';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useState } from 'react';
import { Phone } from 'lucide-react';

const TeamRoster = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStaff = staffMembers.filter(
    staff => staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.position.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardCard 
      title="Team Roster & Contacts" 
      icon="users"
      className="mb-6"
    >
      {/* Department Tabs */}
      <Tabs defaultValue="front-office" className="w-full">
        <TabsList className="border-b border-gray-200 w-full rounded-none bg-transparent pb-0 mb-4 flex flex-wrap">
          <TabsTrigger 
            value="front-office" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Front Office
          </TabsTrigger>
          <TabsTrigger 
            value="housekeeping" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Housekeeping
          </TabsTrigger>
          <TabsTrigger 
            value="fnb" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            F&B
          </TabsTrigger>
          <TabsTrigger 
            value="management" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Management
          </TabsTrigger>
          <TabsTrigger 
            value="maintenance" 
            className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none bg-transparent rounded-none py-2 px-4 -mb-px data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:border-gray-300"
          >
            Maintenance
          </TabsTrigger>
        </TabsList>
        
        {/* Search Bar */}
        <div className="mb-4">
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
            </div>
            <Input 
              type="text" 
              placeholder="Search team members..." 
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <TabsContent value="front-office" className="mt-0">
          {/* Contact Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStaff.map((staff) => (
              <div key={staff.id} className="border rounded-md p-4 flex items-start">
                <Avatar className="h-12 w-12 mr-3">
                  <AvatarFallback className="bg-primary bg-opacity-20 text-primary">
                    {staff.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{staff.name}</h4>
                  <p className="text-sm text-gray-600">{staff.position}</p>
                  <p className="text-sm text-primary mt-1 flex items-center">
                    <Phone className="h-3 w-3 mr-1" />
                    {staff.phone}
                  </p>
                  <p className="text-xs text-gray-500">Shifts: {staff.shifts}</p>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="housekeeping" className="mt-0">
          <p className="text-center py-8 text-gray-500">Housekeeping staff list would be displayed here</p>
        </TabsContent>
        
        <TabsContent value="fnb" className="mt-0">
          <p className="text-center py-8 text-gray-500">F&B staff list would be displayed here</p>
        </TabsContent>
        
        <TabsContent value="management" className="mt-0">
          <p className="text-center py-8 text-gray-500">Management staff list would be displayed here</p>
        </TabsContent>
        
        <TabsContent value="maintenance" className="mt-0">
          <p className="text-center py-8 text-gray-500">Maintenance staff list would be displayed here</p>
        </TabsContent>
      </Tabs>
    </DashboardCard>
  );
};

export default TeamRoster;

import { 
  User,
  Note,
  VIP,
  Group,
  Event,
  ShoutOut,
  InventoryItem,
  InventoryAction,
  StaffMember,
  ParkingPass,
  LocalRecommendation,
  QuickLink,
  CommonTask,
  WeatherForecast,
  CurrentWeather
} from './types';

export const currentUser: User = {
  id: 1,
  name: 'Sarah Wilson',
  role: 'Front Desk Manager'
};

export const frontDeskNotes: Note[] = [
  {
    id: 1,
    text: 'Room 503 complained about AC not working. Maintenance notified, will check by 2pm.',
    author: 'Amy',
    timestamp: '8:15 AM'
  },
  {
    id: 2,
    text: 'Delivery for Johnson wedding cake expected between 10-11am. Direct to kitchen.',
    author: 'Carlos',
    timestamp: '7:30 AM'
  },
  {
    id: 3,
    text: 'Housekeeping needs extra towels for floors 6-8. Called supplier, delivery tomorrow.',
    author: 'Mark',
    timestamp: 'Yesterday'
  }
];

export const vipsForToday: VIP[] = [
  {
    id: 1,
    name: 'Mr. Thomas Chen',
    type: 'Diamond Elite',
    room: 'Penthouse Suite',
    arrivalTime: '4:30 PM',
    specialRequests: [
      'Champagne and fruit basket in room',
      'Late checkout on Thursday',
      'Car service for Wednesday dinner'
    ]
  },
  {
    id: 2,
    name: 'Ms. Jennifer Martinez',
    type: 'Gold Member',
    room: 'Executive Suite',
    arrivalTime: '6:00 PM',
    specialRequests: [
      'Quiet room away from elevator',
      'Extra towels'
    ]
  }
];

export const groupsInHouse: Group[] = [
  {
    id: 1,
    name: 'Johnson Wedding Party',
    roomCount: 12,
    blockCode: 'JWED0615',
    dateRange: 'June 15-18',
    location: 'Floors 5-6',
    contactName: 'Robert Johnson',
    contactPhone: '555-867-5309',
    notes: 'Wedding at Grand Ballroom on Saturday. Welcome reception tonight in Emperyan Lounge.'
  },
  {
    id: 2,
    name: 'Tech Innovation Conference',
    roomCount: 24,
    blockCode: 'TECH0616',
    dateRange: 'June 16-18',
    location: 'Floors 7-8',
    contactName: 'Lisa Chen',
    contactPhone: '555-123-4567',
    notes: 'Daily meeting in Oceanview Rooms 1-3. A/V requirements confirmed.'
  }
];

export const todaysEvents: Event[] = [
  {
    id: 1,
    title: 'Tech Conference',
    location: 'Oceanview Room',
    timeRange: '9AM-12PM',
    type: 'Meeting',
    attendees: '~50 people',
    date: 'June 15, 2023'
  },
  {
    id: 2,
    title: 'Johnson Wedding Rehearsal',
    location: 'Grand Ballroom',
    timeRange: '2PM-5PM',
    type: 'Wedding',
    attendees: '~25 people',
    date: 'June 15, 2023'
  }
];

export const upcomingEvents: Event[] = [
  {
    id: 3,
    title: 'Johnson Wedding Reception',
    location: 'Grand Ballroom',
    timeRange: '6:00 PM - 11:00 PM',
    type: 'Wedding',
    attendees: '112 guests',
    date: 'June 15, 2023'
  },
  {
    id: 4,
    title: 'Tech Innovation Conference',
    location: 'Oceanview Rooms 1-3',
    timeRange: '9:00 AM - 5:00 PM',
    type: 'Corporate',
    attendees: '85 attendees',
    date: 'June 16, 2023'
  },
  {
    id: 5,
    title: 'Monthly Staff Meeting',
    location: 'Employee Lounge',
    timeRange: '2:00 PM - 3:30 PM',
    type: 'Internal',
    attendees: 'All staff',
    date: 'June 18, 2023'
  }
];

export const parkingReminders: string[] = [
  'Wedding guests receive validated parking',
  'Mr. Chen\'s driver has reserved space #1'
];

export const shoutOuts: ShoutOut[] = [
  {
    id: 1,
    text: 'Shoutout to Jordan for handling 3 complaints solo yesterday and turning them into positive reviews!',
    author: 'Sarah Wilson',
    date: 'June 14'
  },
  {
    id: 2,
    text: 'Thanks to the entire night shift team for going above and beyond during the power outage. Guests were impressed with your professionalism!',
    author: 'Mark Johnson',
    date: 'June 13'
  },
  {
    id: 3,
    text: 'Congratulations to Emily on her 5-year work anniversary with Hilton!',
    author: 'Management Team',
    date: 'June 10'
  }
];

export const motivationalQuote = {
  text: 'Hospitality is making someone feel at home, even if you wish they were.',
  author: 'Anonymous'
};

export const inventoryItems: InventoryItem[] = [
  {
    id: 1,
    name: 'Key Cards',
    currentAmount: 324,
    minRequired: 100,
    status: 'In Stock',
    lastUpdated: 'June 14, 2023',
    lastUpdatedBy: 'Sarah W.'
  },
  {
    id: 2,
    name: 'Parking Passes',
    currentAmount: 42,
    minRequired: 50,
    status: 'Order Soon',
    lastUpdated: 'June 13, 2023',
    lastUpdatedBy: 'Michael B.'
  },
  {
    id: 3,
    name: 'Pens',
    currentAmount: 87,
    minRequired: 50,
    status: 'In Stock',
    lastUpdated: 'June 12, 2023',
    lastUpdatedBy: 'Jordan T.'
  },
  {
    id: 4,
    name: 'Welcome Packets',
    currentAmount: 12,
    minRequired: 25,
    status: 'Low Stock',
    lastUpdated: 'June 14, 2023',
    lastUpdatedBy: 'Emily C.'
  }
];

export const inventoryHistory: InventoryAction[] = [
  {
    id: 1,
    type: 'increase',
    user: 'Sarah Wilson',
    item: 'Key Cards',
    from: 280,
    to: 324,
    timestamp: 'June 14, 10:32 AM'
  },
  {
    id: 2,
    type: 'decrease',
    user: 'Michael Brown',
    item: 'Parking Passes',
    from: 54,
    to: 42,
    timestamp: 'June 13, 3:15 PM'
  },
  {
    id: 3,
    type: 'add',
    user: 'Jordan Taylor',
    item: 'Norfolk Visitor Guides',
    to: 50,
    timestamp: 'June 12, 11:47 AM'
  }
];

export const staffMembers: StaffMember[] = [
  {
    id: 1,
    name: 'Sarah Wilson',
    position: 'Front Desk Manager',
    phone: '(555) 123-4567',
    shifts: 'M-F, 7am-3pm',
    status: 'Active',
    shiftTime: '7:00 AM - 3:00 PM'
  },
  {
    id: 2,
    name: 'Michael Brown',
    position: 'Concierge',
    phone: '(555) 123-7890',
    shifts: 'M-F, 8am-4pm',
    status: 'Active',
    shiftTime: '8:00 AM - 4:00 PM'
  },
  {
    id: 3,
    name: 'Jordan Taylor',
    position: 'Front Desk Agent',
    phone: '(555) 123-2468',
    shifts: 'Variable',
    status: 'Active',
    shiftTime: '10:00 AM - 6:00 PM'
  },
  {
    id: 4,
    name: 'Emily Chen',
    position: 'Front Desk Agent',
    phone: '(555) 123-1357',
    shifts: 'Variable',
    status: 'Coming Soon',
    shiftTime: '3:00 PM - 11:00 PM'
  }
];

export const parkingPasses: ParkingPass[] = [
  {
    id: 1,
    name: 'Johnson Wedding VIPs',
    details: '5 Premium Passes · Valid June 15-18',
    validDate: 'June 15-18',
    isVIP: true
  },
  {
    id: 2,
    name: 'Mr. Thomas Chen',
    details: 'Reserved Space #1 · June 15-17',
    validDate: 'June 15-17',
    isVIP: false
  },
  {
    id: 3,
    name: 'Tech Conference Speakers',
    details: '3 Premium Passes · Valid June 16-18',
    validDate: 'June 16-18',
    isVIP: false
  }
];

export const localRecommendations: LocalRecommendation[] = [
  {
    id: 1,
    category: 'Dining Options',
    items: [
      { name: 'Seafood Grill', distance: '0.2 mi' },
      { name: 'Harbor View', distance: '0.3 mi' },
      { name: 'Coastal Kitchen', distance: '0.5 mi' }
    ]
  },
  {
    id: 2,
    category: 'Attractions',
    items: [
      { name: 'Maritime Museum', distance: '0.4 mi' },
      { name: 'Waterside District', distance: '0.6 mi' },
      { name: 'Norfolk Botanical', distance: '1.5 mi' }
    ]
  },
  {
    id: 3,
    category: 'Transportation',
    items: [
      { name: 'The Tide Light Rail', distance: '0.3 mi' },
      { name: 'Taxi Service' },
      { name: 'Airport Shuttle' }
    ]
  }
];

export const quickLinks: QuickLink[] = [
  {
    id: 1,
    name: 'Kipsu',
    description: 'Guest messaging',
    icon: 'message-square',
    url: '#'
  },
  {
    id: 2,
    name: 'LeftMyStuff',
    description: 'Lost & found',
    icon: 'archive',
    url: '#'
  },
  {
    id: 3,
    name: 'Lobby',
    description: 'Hilton resources',
    icon: 'home',
    url: '#'
  },
  {
    id: 4,
    name: 'TIBA Norfolk',
    description: 'Parking system',
    icon: 'car',
    url: '#'
  },
  {
    id: 5,
    name: 'Teams',
    description: 'Communication',
    icon: 'users',
    url: '#'
  },
  {
    id: 6,
    name: 'HotSOS',
    description: 'Maintenance requests',
    icon: 'tool',
    url: '#'
  },
  {
    id: 7,
    name: 'Ambience Key',
    description: 'Music system',
    icon: 'music',
    url: '#'
  },
  {
    id: 8,
    name: 'Hilton Norfolk',
    description: 'Hotel website',
    icon: 'globe',
    url: '#'
  }
];

export const commonTasks: CommonTask[] = [
  {
    id: 1,
    title: 'Generate End of Day Report',
    description: 'Create daily summary report',
    icon: 'file-text',
    url: '#'
  },
  {
    id: 2,
    title: 'Send Pre-Arrival Emails',
    description: 'For tomorrow\'s guests',
    icon: 'mail',
    url: '#'
  },
  {
    id: 3,
    title: 'Update Meeting Room Status',
    description: 'Check readiness for events',
    icon: 'calendar',
    url: '#'
  },
  {
    id: 4,
    title: 'Guest Lookup',
    description: 'Search guest information',
    icon: 'search',
    url: '#'
  }
];

export const weatherForecast: WeatherForecast[] = [
  { day: 'Mon', icon: 'sun', temp: '82°' },
  { day: 'Tue', icon: 'cloud-sun', temp: '79°' },
  { day: 'Wed', icon: 'cloud', temp: '76°' },
  { day: 'Thu', icon: 'cloud-rain', temp: '72°' },
  { day: 'Fri', icon: 'sun', temp: '77°' }
];

export const currentWeather: CurrentWeather = {
  location: 'Norfolk, VA',
  temperature: '78°F',
  condition: 'Sunny',
  feelsLike: '80°F',
  lastUpdated: '10 mins ago',
  icon: 'sun'
};

export const getCurrentDate = () => {
  const options: Intl.DateTimeFormatOptions = { 
    month: 'long', 
    day: 'numeric', 
    year: 'numeric' 
  };
  return new Date().toLocaleDateString('en-US', options);
};

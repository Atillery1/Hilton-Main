// Common types used throughout the application

export interface User {
  id: number;
  name: string;
  role: string;
  imageUrl?: string;
}

export interface Note {
  id: number;
  text: string;
  author: string;
  timestamp: string;
}

export interface VIP {
  id: number;
  name: string;
  type: string;
  room: string;
  arrivalTime: string;
  specialRequests: string[];
}

export interface Group {
  id: number;
  name: string;
  roomCount: number;
  blockCode: string;
  dateRange: string;
  location: string;
  contactName: string;
  contactPhone: string;
  notes: string;
}

export interface Event {
  id: number;
  title: string;
  location: string;
  timeRange: string;
  type: string;
  attendees: string;
  date: string;
}

export interface ShoutOut {
  id: number;
  text: string;
  author: string;
  date: string;
}

export interface InventoryItem {
  id: number;
  name: string;
  currentAmount: number;
  minRequired: number;
  status: 'In Stock' | 'Order Soon' | 'Low Stock';
  lastUpdated: string;
  lastUpdatedBy: string;
}

export interface InventoryAction {
  id: number;
  type: 'increase' | 'decrease' | 'add';
  user: string;
  item: string;
  from?: number;
  to?: number;
  timestamp: string;
}

export interface StaffMember {
  id: number;
  name: string;
  position: string;
  phone: string;
  shifts: string;
  imageUrl?: string;
  status?: 'Active' | 'Coming Soon' | 'Off Duty';
  shiftTime?: string;
}

export interface ParkingPass {
  id: number;
  name: string;
  details: string;
  validDate: string;
  isVIP: boolean;
}

export interface LocalRecommendation {
  id: number;
  category: string;
  items: {
    name: string;
    distance?: string;
  }[];
}

export interface QuickLink {
  id: number;
  name: string;
  description: string;
  icon: string;
  url: string;
}

export interface CommonTask {
  id: number;
  title: string;
  description: string;
  icon: string;
  url: string;
}

export interface WeatherForecast {
  day: string;
  icon: string;
  temp: string;
}

export interface CurrentWeather {
  location: string;
  temperature: string;
  condition: string;
  feelsLike: string;
  lastUpdated: string;
  icon: string;
}

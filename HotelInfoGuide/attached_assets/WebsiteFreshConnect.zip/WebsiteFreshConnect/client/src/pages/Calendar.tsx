import { useEffect } from 'react';
import CalendarView from '@/components/calendar/CalendarView';
import UpcomingEvents from '@/components/calendar/UpcomingEvents';

const Calendar = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Calendar & Events | Front Desk Hub";
  }, []);

  return (
    <div className="space-y-6">
      <CalendarView />
      <UpcomingEvents />
    </div>
  );
};

export default Calendar;

import { useEffect } from 'react';
import VipsForToday from '@/components/guest/VipsForToday';
import GroupsInHouse from '@/components/guest/GroupsInHouse';
import RoomTaxCalculator from '@/components/guest/RoomTaxCalculator';
import ParkingPassReminders from '@/components/guest/ParkingPassReminders';
import LocalRecommendations from '@/components/guest/LocalRecommendations';

const Guest = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Guest Services | Front Desk Hub";
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <VipsForToday />
        <GroupsInHouse />
        <RoomTaxCalculator />
        <ParkingPassReminders />
        <LocalRecommendations />
      </div>
    </div>
  );
};

export default Guest;

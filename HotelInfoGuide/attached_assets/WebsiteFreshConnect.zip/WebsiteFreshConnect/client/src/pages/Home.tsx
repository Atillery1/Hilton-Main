import { useEffect } from 'react';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import TodaysEvents from '@/components/dashboard/TodaysEvents';
import ShoutOuts from '@/components/dashboard/ShoutOuts';
import MotivationalQuote from '@/components/dashboard/MotivationalQuote';
import WeatherWidget from '@/components/dashboard/WeatherWidget';
import FrontDeskNotes from '@/components/dashboard/FrontDeskNotes';
import QuickActions from '@/components/dashboard/QuickActions';

const Home = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Home | Front Desk Hub";
  }, []);

  return (
    <DashboardLayout>
      {/* Left Column */}
      <div className="w-full lg:w-2/3 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <WeatherWidget />
          <MotivationalQuote />
        </div>
        <TodaysEvents />
        <ShoutOuts />
      </div>
      
      {/* Right Column */}
      <div className="w-full lg:w-1/3 space-y-8">
        <FrontDeskNotes />
        <QuickActions />
      </div>
    </DashboardLayout>
  );
};

export default Home;

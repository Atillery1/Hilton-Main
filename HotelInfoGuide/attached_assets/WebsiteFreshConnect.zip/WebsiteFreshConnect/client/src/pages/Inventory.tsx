import { useEffect } from 'react';
import InventoryManagement from '@/components/inventory/InventoryManagement';
import InventoryHistory from '@/components/inventory/InventoryHistory';

const Inventory = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Inventory Logs | Front Desk Hub";
  }, []);

  return (
    <div className="space-y-6">
      <InventoryManagement />
      <InventoryHistory />
    </div>
  );
};

export default Inventory;

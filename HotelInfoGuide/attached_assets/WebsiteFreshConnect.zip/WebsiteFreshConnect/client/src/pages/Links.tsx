import { useEffect } from 'react';
import QuickLinks from '@/components/links/QuickLinks';
import PasswordHub from '@/components/links/PasswordHub';
import CommonTasks from '@/components/links/CommonTasks';

const Links = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Quick Links | Front Desk Hub";
  }, []);

  return (
    <div className="space-y-6">
      <QuickLinks />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PasswordHub />
        <CommonTasks />
      </div>
    </div>
  );
};

export default Links;

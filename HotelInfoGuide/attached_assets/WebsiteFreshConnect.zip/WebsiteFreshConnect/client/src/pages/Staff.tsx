import { useEffect } from 'react';
import StaffSchedule from '@/components/staff/StaffSchedule';
import TeamRoster from '@/components/staff/TeamRoster';
import SuggestionBox from '@/components/staff/SuggestionBox';

const Staff = () => {
  // Set document title when component mounts
  useEffect(() => {
    document.title = "Staff Tools | Front Desk Hub";
  }, []);

  return (
    <div className="space-y-6">
      <StaffSchedule />
      <TeamRoster />
      <SuggestionBox />
    </div>
  );
};

export default Staff;

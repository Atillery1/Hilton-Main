import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the front desk hub
  
  // Get current weather data - Placeholder API endpoint
  app.get('/api/weather', (req, res) => {
    // In a real app, this would fetch weather data from an external API
    const currentWeather = {
      location: 'Norfolk, VA',
      temperature: '78°F',
      condition: 'Sunny',
      feelsLike: '80°F',
      lastUpdated: '10 mins ago',
      icon: 'sun'
    };
    
    // Weather forecast for the week
    const forecast = [
      { day: 'Mon', icon: 'sun', temp: '82°' },
      { day: 'Tue', icon: 'cloud-sun', temp: '79°' },
      { day: 'Wed', icon: 'cloud', temp: '76°' },
      { day: 'Thu', icon: 'cloud-rain', temp: '72°' },
      { day: 'Fri', icon: 'sun', temp: '77°' }
    ];
    
    res.json({ currentWeather, forecast });
  });
  
  // Get hotel events
  app.get('/api/events', (req, res) => {
    // In a real app, this would fetch event data from a database
    const events = [
      {
        id: 1,
        title: 'Johnson Wedding Reception',
        location: 'Grand Ballroom',
        timeRange: '6:00 PM - 11:00 PM',
        type: 'Wedding',
        attendees: '112 guests',
        date: 'June 15, 2023'
      },
      {
        id: 2,
        title: 'Tech Innovation Conference',
        location: 'Oceanview Rooms 1-3',
        timeRange: '9:00 AM - 5:00 PM',
        type: 'Corporate',
        attendees: '85 attendees',
        date: 'June 16, 2023'
      },
      {
        id: 3,
        title: 'Monthly Staff Meeting',
        location: 'Employee Lounge',
        timeRange: '2:00 PM - 3:30 PM',
        type: 'Internal',
        attendees: 'All staff',
        date: 'June 18, 2023'
      }
    ];
    
    res.json({ events });
  });
  
  // Get VIPs
  app.get('/api/vips', (req, res) => {
    // In a real app, this would fetch VIP data from a database
    const vips = [
      {
        id: 1,
        name: 'Mr. Thomas Chen',
        type: 'Diamond Elite',
        room: 'Penthouse Suite',
        arrivalTime: '4:30 PM',
        specialRequests: [
          'Champagne and fruit basket in room',
          'Late checkout on Thursday',
          'Car service for Wednesday dinner'
        ]
      },
      {
        id: 2,
        name: 'Ms. Jennifer Martinez',
        type: 'Gold Member',
        room: 'Executive Suite',
        arrivalTime: '6:00 PM',
        specialRequests: [
          'Quiet room away from elevator',
          'Extra towels'
        ]
      }
    ];
    
    res.json({ vips });
  });
  
  // Get inventory items
  app.get('/api/inventory', (req, res) => {
    // In a real app, this would fetch inventory data from a database
    const inventory = [
      {
        id: 1,
        name: 'Key Cards',
        currentAmount: 324,
        minRequired: 100,
        status: 'In Stock',
        lastUpdated: 'June 14, 2023',
        lastUpdatedBy: 'Sarah W.'
      },
      {
        id: 2,
        name: 'Parking Passes',
        currentAmount: 42,
        minRequired: 50,
        status: 'Order Soon',
        lastUpdated: 'June 13, 2023',
        lastUpdatedBy: 'Michael B.'
      },
      {
        id: 3,
        name: 'Pens',
        currentAmount: 87,
        minRequired: 50,
        status: 'In Stock',
        lastUpdated: 'June 12, 2023',
        lastUpdatedBy: 'Jordan T.'
      },
      {
        id: 4,
        name: 'Welcome Packets',
        currentAmount: 12,
        minRequired: 25,
        status: 'Low Stock',
        lastUpdated: 'June 14, 2023',
        lastUpdatedBy: 'Emily C.'
      }
    ];
    
    res.json({ inventory });
  });
  
  // Update inventory item
  app.post('/api/inventory/update', (req, res) => {
    const { id, currentAmount } = req.body;
    
    // In a real app, this would update the inventory in a database
    // For now, just return success
    res.json({ 
      success: true, 
      message: `Updated item #${id} to ${currentAmount} units`
    });
  });
  
  // Add new shoutout
  app.post('/api/shoutouts', (req, res) => {
    const { text, author } = req.body;
    
    // In a real app, this would store the shoutout in a database
    // For now, just return success with a mock ID
    res.json({
      success: true,
      id: Math.floor(Math.random() * 1000),
      text,
      author,
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric' })
    });
  });
  
  // Submit staff suggestion
  app.post('/api/suggestions', (req, res) => {
    const { title, category, details, isAnonymous } = req.body;
    
    // In a real app, this would store the suggestion in a database
    // For now, just return success
    res.json({
      success: true,
      message: 'Suggestion submitted successfully'
    });
  });
  
  // Create parking pass
  app.post('/api/parking-passes', (req, res) => {
    const { name, validDate, spaces, isVIP } = req.body;
    
    // In a real app, this would create a new parking pass in a database
    // For now, just return success with a mock ID
    res.json({
      success: true,
      id: Math.floor(Math.random() * 1000),
      message: 'Parking pass created successfully'
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}

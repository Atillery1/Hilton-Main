import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  imageUrl: true,
});

// Events table
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  timeRange: text("time_range").notNull(),
  type: text("type").notNull(),
  attendees: text("attendees").notNull(),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEventSchema = createInsertSchema(events).pick({
  title: true,
  location: true,
  timeRange: true,
  type: true,
  attendees: true,
  date: true,
});

// VIPs table
export const vips = pgTable("vips", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  room: text("room").notNull(),
  arrivalTime: text("arrival_time").notNull(),
  specialRequests: json("special_requests").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertVipSchema = createInsertSchema(vips).pick({
  name: true,
  type: true,
  room: true,
  arrivalTime: true,
  specialRequests: true,
});

// Groups in house table
export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  roomCount: integer("room_count").notNull(),
  blockCode: text("block_code").notNull(),
  dateRange: text("date_range").notNull(),
  location: text("location").notNull(),
  contactName: text("contact_name").notNull(),
  contactPhone: text("contact_phone").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGroupSchema = createInsertSchema(groups).pick({
  name: true,
  roomCount: true,
  blockCode: true,
  dateRange: true,
  location: true,
  contactName: true,
  contactPhone: true,
  notes: true,
});

// Front desk notes table
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  author: text("author").notNull(),
  timestamp: text("timestamp").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertNoteSchema = createInsertSchema(notes).pick({
  text: true,
  author: true,
  timestamp: true,
});

// Shoutouts table
export const shoutouts = pgTable("shoutouts", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  author: text("author").notNull(),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertShoutoutSchema = createInsertSchema(shoutouts).pick({
  text: true,
  author: true,
  date: true,
});

// Inventory items table
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  currentAmount: integer("current_amount").notNull(),
  minRequired: integer("min_required").notNull(),
  status: text("status").notNull(),
  lastUpdated: text("last_updated").notNull(),
  lastUpdatedBy: text("last_updated_by").notNull(),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).pick({
  name: true,
  currentAmount: true,
  minRequired: true,
  status: true,
  lastUpdated: true,
  lastUpdatedBy: true,
  category: true,
});

// Inventory history table
export const inventoryHistory = pgTable("inventory_history", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  user: text("user").notNull(),
  item: text("item").notNull(),
  from: integer("from"),
  to: integer("to"),
  timestamp: text("timestamp").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInventoryHistorySchema = createInsertSchema(inventoryHistory).pick({
  type: true,
  user: true,
  item: true,
  from: true,
  to: true,
  timestamp: true,
});

// Parking passes table
export const parkingPasses = pgTable("parking_passes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  details: text("details").notNull(),
  validDate: text("valid_date").notNull(),
  isVIP: boolean("is_vip").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertParkingPassSchema = createInsertSchema(parkingPasses).pick({
  name: true,
  details: true,
  validDate: true,
  isVIP: true,
});

// Staff suggestions table
export const suggestions = pgTable("suggestions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  details: text("details").notNull(),
  isAnonymous: boolean("is_anonymous").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSuggestionSchema = createInsertSchema(suggestions).pick({
  title: true,
  category: true,
  details: true,
  isAnonymous: true,
});

// Types exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertVip = z.infer<typeof insertVipSchema>;
export type Vip = typeof vips.$inferSelect;

export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

export type InsertShoutout = z.infer<typeof insertShoutoutSchema>;
export type Shoutout = typeof shoutouts.$inferSelect;

export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;

export type InsertInventoryHistory = z.infer<typeof insertInventoryHistorySchema>;
export type InventoryHistory = typeof inventoryHistory.$inferSelect;

export type InsertParkingPass = z.infer<typeof insertParkingPassSchema>;
export type ParkingPass = typeof parkingPasses.$inferSelect;

export type InsertSuggestion = z.infer<typeof insertSuggestionSchema>;
export type Suggestion = typeof suggestions.$inferSelect;
